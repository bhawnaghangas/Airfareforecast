```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
sns.set()
%matplotlib inline
import warnings
warnings.filterwarnings('ignore')
```


```python
df = pd.read_excel('Data_Train.xlsx')
```


```python
df.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Airline</th>
      <th>Date_of_Journey</th>
      <th>Source</th>
      <th>Destination</th>
      <th>Route</th>
      <th>Dep_Time</th>
      <th>Arrival_Time</th>
      <th>Duration</th>
      <th>Total_Stops</th>
      <th>Additional_Info</th>
      <th>Price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>IndiGo</td>
      <td>24/03/2019</td>
      <td>Banglore</td>
      <td>New Delhi</td>
      <td>BLR → DEL</td>
      <td>22:20</td>
      <td>01:10 22 Mar</td>
      <td>2h 50m</td>
      <td>non-stop</td>
      <td>Null</td>
      <td>3897</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Air India</td>
      <td>1/05/2019</td>
      <td>Kolkata</td>
      <td>Banglore</td>
      <td>CCU → IXR → BBI → BLR</td>
      <td>05:50</td>
      <td>13:15</td>
      <td>7h 25m</td>
      <td>2 stops</td>
      <td>Null</td>
      <td>7662</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Jet Airways</td>
      <td>9/06/2019</td>
      <td>Delhi</td>
      <td>Cochin</td>
      <td>DEL → LKO → BOM → COK</td>
      <td>09:25</td>
      <td>04:25 10 Jun</td>
      <td>19h</td>
      <td>2 stops</td>
      <td>Null</td>
      <td>13882</td>
    </tr>
    <tr>
      <th>3</th>
      <td>IndiGo</td>
      <td>12/05/2019</td>
      <td>Kolkata</td>
      <td>Banglore</td>
      <td>CCU → NAG → BLR</td>
      <td>18:05</td>
      <td>23:30</td>
      <td>5h 25m</td>
      <td>1 stop</td>
      <td>Null</td>
      <td>6218</td>
    </tr>
    <tr>
      <th>4</th>
      <td>IndiGo</td>
      <td>01/03/2019</td>
      <td>Banglore</td>
      <td>New Delhi</td>
      <td>BLR → NAG → DEL</td>
      <td>16:50</td>
      <td>21:35</td>
      <td>4h 45m</td>
      <td>1 stop</td>
      <td>Null</td>
      <td>13302</td>
    </tr>
    <tr>
      <th>5</th>
      <td>SpiceJet</td>
      <td>24/06/2019</td>
      <td>Kolkata</td>
      <td>Banglore</td>
      <td>CCU → BLR</td>
      <td>09:00</td>
      <td>11:25</td>
      <td>2h 25m</td>
      <td>non-stop</td>
      <td>Null</td>
      <td>3873</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Jet Airways</td>
      <td>12/03/2019</td>
      <td>Banglore</td>
      <td>New Delhi</td>
      <td>BLR → BOM → DEL</td>
      <td>18:55</td>
      <td>10:25 13 Mar</td>
      <td>15h 30m</td>
      <td>1 stop</td>
      <td>In-flight meal not included</td>
      <td>11087</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Jet Airways</td>
      <td>01/03/2019</td>
      <td>Banglore</td>
      <td>New Delhi</td>
      <td>BLR → BOM → DEL</td>
      <td>08:00</td>
      <td>05:05 02 Mar</td>
      <td>21h 5m</td>
      <td>1 stop</td>
      <td>Null</td>
      <td>22270</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Jet Airways</td>
      <td>12/03/2019</td>
      <td>Banglore</td>
      <td>New Delhi</td>
      <td>BLR → BOM → DEL</td>
      <td>08:55</td>
      <td>10:25 13 Mar</td>
      <td>25h 30m</td>
      <td>1 stop</td>
      <td>In-flight meal not included</td>
      <td>11087</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Multiple carriers</td>
      <td>27/05/2019</td>
      <td>Delhi</td>
      <td>Cochin</td>
      <td>DEL → BOM → COK</td>
      <td>11:25</td>
      <td>19:15</td>
      <td>7h 50m</td>
      <td>1 stop</td>
      <td>Null</td>
      <td>8625</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 10683 entries, 0 to 10682
    Data columns (total 11 columns):
     #   Column           Non-Null Count  Dtype 
    ---  ------           --------------  ----- 
     0   Airline          10683 non-null  object
     1   Date_of_Journey  10683 non-null  object
     2   Source           10683 non-null  object
     3   Destination      10683 non-null  object
     4   Route            10682 non-null  object
     5   Dep_Time         10683 non-null  object
     6   Arrival_Time     10683 non-null  object
     7   Duration         10683 non-null  object
     8   Total_Stops      10682 non-null  object
     9   Additional_Info  10683 non-null  object
     10  Price            10683 non-null  int64 
    dtypes: int64(1), object(10)
    memory usage: 918.2+ KB
    


```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>10683.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>9087.064121</td>
    </tr>
    <tr>
      <th>std</th>
      <td>4611.359167</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1759.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>5277.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>8372.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>12373.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>79512.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.describe(include = ['O']).T
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>count</th>
      <th>unique</th>
      <th>top</th>
      <th>freq</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Airline</th>
      <td>10683</td>
      <td>12</td>
      <td>Jet Airways</td>
      <td>3849</td>
    </tr>
    <tr>
      <th>Date_of_Journey</th>
      <td>10683</td>
      <td>44</td>
      <td>18/05/2019</td>
      <td>504</td>
    </tr>
    <tr>
      <th>Source</th>
      <td>10683</td>
      <td>5</td>
      <td>Delhi</td>
      <td>4537</td>
    </tr>
    <tr>
      <th>Destination</th>
      <td>10683</td>
      <td>6</td>
      <td>Cochin</td>
      <td>4537</td>
    </tr>
    <tr>
      <th>Route</th>
      <td>10682</td>
      <td>128</td>
      <td>DEL → BOM → COK</td>
      <td>2376</td>
    </tr>
    <tr>
      <th>Dep_Time</th>
      <td>10683</td>
      <td>222</td>
      <td>18:55</td>
      <td>233</td>
    </tr>
    <tr>
      <th>Arrival_Time</th>
      <td>10683</td>
      <td>1343</td>
      <td>19:00</td>
      <td>423</td>
    </tr>
    <tr>
      <th>Duration</th>
      <td>10683</td>
      <td>368</td>
      <td>2h 50m</td>
      <td>550</td>
    </tr>
    <tr>
      <th>Total_Stops</th>
      <td>10682</td>
      <td>5</td>
      <td>1 stop</td>
      <td>5625</td>
    </tr>
    <tr>
      <th>Additional_Info</th>
      <td>10683</td>
      <td>10</td>
      <td>Null</td>
      <td>8347</td>
    </tr>
  </tbody>
</table>
</div>




```python
for i in df.columns:
    print(f'The unique values in features {i}: ',df[i].unique(), sep = '\n')
    print('----------------------------------------------------------------')
```

    The unique values in features Airline: 
    ['IndiGo' 'Air India' 'Jet Airways' 'SpiceJet' 'Multiple carriers' 'GoAir'
     'Vistara' 'Air Asia' 'Vistara Premium economy' 'Jet Airways Business'
     'Multiple carriers Premium economy' 'Trujet']
    ----------------------------------------------------------------
    The unique values in features Date_of_Journey: 
    ['24/03/2019' '1/05/2019' '9/06/2019' '12/05/2019' '01/03/2019'
     '24/06/2019' '12/03/2019' '27/05/2019' '1/06/2019' '18/04/2019'
     '9/05/2019' '24/04/2019' '3/03/2019' '15/04/2019' '12/06/2019'
     '6/03/2019' '21/03/2019' '3/04/2019' '6/05/2019' '15/05/2019'
     '18/06/2019' '15/06/2019' '6/04/2019' '18/05/2019' '27/06/2019'
     '21/05/2019' '06/03/2019' '3/06/2019' '15/03/2019' '3/05/2019'
     '9/03/2019' '6/06/2019' '24/05/2019' '09/03/2019' '1/04/2019'
     '21/04/2019' '21/06/2019' '27/03/2019' '18/03/2019' '12/04/2019'
     '9/04/2019' '1/03/2019' '03/03/2019' '27/04/2019']
    ----------------------------------------------------------------
    The unique values in features Source: 
    ['Banglore' 'Kolkata' 'Delhi' 'Chennai' 'Mumbai']
    ----------------------------------------------------------------
    The unique values in features Destination: 
    ['New Delhi' 'Banglore' 'Cochin' 'Kolkata' 'Delhi' 'Hyderabad']
    ----------------------------------------------------------------
    The unique values in features Route: 
    ['BLR → DEL' 'CCU → IXR → BBI → BLR' 'DEL → LKO → BOM → COK'
     'CCU → NAG → BLR' 'BLR → NAG → DEL' 'CCU → BLR' 'BLR → BOM → DEL'
     'DEL → BOM → COK' 'DEL → BLR → COK' 'MAA → CCU' 'CCU → BOM → BLR'
     'DEL → AMD → BOM → COK' 'DEL → PNQ → COK' 'DEL → CCU → BOM → COK'
     'BLR → COK → DEL' 'DEL → IDR → BOM → COK' 'DEL → LKO → COK'
     'CCU → GAU → DEL → BLR' 'DEL → NAG → BOM → COK' 'CCU → MAA → BLR'
     'DEL → HYD → COK' 'CCU → HYD → BLR' 'DEL → COK' 'CCU → DEL → BLR'
     'BLR → BOM → AMD → DEL' 'BOM → DEL → HYD' 'DEL → MAA → COK' 'BOM → HYD'
     'DEL → BHO → BOM → COK' 'DEL → JAI → BOM → COK' 'DEL → ATQ → BOM → COK'
     'DEL → JDH → BOM → COK' 'CCU → BBI → BOM → BLR' 'BLR → MAA → DEL'
     'DEL → GOI → BOM → COK' 'DEL → BDQ → BOM → COK' 'CCU → JAI → BOM → BLR'
     'CCU → BBI → BLR' 'BLR → HYD → DEL' 'DEL → TRV → COK'
     'CCU → IXR → DEL → BLR' 'DEL → IXU → BOM → COK' 'CCU → IXB → BLR'
     'BLR → BOM → JDH → DEL' 'DEL → UDR → BOM → COK' 'DEL → HYD → MAA → COK'
     'CCU → BOM → COK → BLR' 'BLR → CCU → DEL' 'CCU → BOM → GOI → BLR'
     'DEL → RPR → NAG → BOM → COK' 'DEL → HYD → BOM → COK'
     'CCU → DEL → AMD → BLR' 'CCU → PNQ → BLR' 'BLR → CCU → GAU → DEL'
     'CCU → DEL → COK → BLR' 'BLR → PNQ → DEL' 'BOM → JDH → DEL → HYD'
     'BLR → BOM → BHO → DEL' 'DEL → AMD → COK' 'BLR → LKO → DEL'
     'CCU → GAU → BLR' 'BOM → GOI → HYD' 'CCU → BOM → AMD → BLR'
     'CCU → BBI → IXR → DEL → BLR' 'DEL → DED → BOM → COK'
     'DEL → MAA → BOM → COK' 'BLR → AMD → DEL' 'BLR → VGA → DEL'
     'CCU → JAI → DEL → BLR' 'CCU → AMD → BLR' 'CCU → VNS → DEL → BLR'
     'BLR → BOM → IDR → DEL' 'BLR → BBI → DEL' 'BLR → GOI → DEL'
     'BOM → AMD → ISK → HYD' 'BOM → DED → DEL → HYD' 'DEL → IXC → BOM → COK'
     'CCU → PAT → BLR' 'BLR → CCU → BBI → DEL' 'CCU → BBI → HYD → BLR'
     'BLR → BOM → NAG → DEL' 'BLR → CCU → BBI → HYD → DEL' 'BLR → GAU → DEL'
     'BOM → BHO → DEL → HYD' 'BOM → JLR → HYD' 'BLR → HYD → VGA → DEL'
     'CCU → KNU → BLR' 'CCU → BOM → PNQ → BLR' 'DEL → BBI → COK'
     'BLR → VGA → HYD → DEL' 'BOM → JDH → JAI → DEL → HYD'
     'DEL → GWL → IDR → BOM → COK' 'CCU → RPR → HYD → BLR' 'CCU → VTZ → BLR'
     'CCU → DEL → VGA → BLR' 'BLR → BOM → IDR → GWL → DEL'
     'CCU → DEL → COK → TRV → BLR' 'BOM → COK → MAA → HYD' 'BOM → NDC → HYD'
     'BLR → BDQ → DEL' 'CCU → BOM → TRV → BLR' 'CCU → BOM → HBX → BLR'
     'BOM → BDQ → DEL → HYD' 'BOM → CCU → HYD' 'BLR → TRV → COK → DEL'
     'BLR → IDR → DEL' 'CCU → IXZ → MAA → BLR' 'CCU → GAU → IMF → DEL → BLR'
     'BOM → GOI → PNQ → HYD' 'BOM → BLR → CCU → BBI → HYD' 'BOM → MAA → HYD'
     'BLR → BOM → UDR → DEL' 'BOM → UDR → DEL → HYD' 'BLR → VGA → VTZ → DEL'
     'BLR → HBX → BOM → BHO → DEL' 'CCU → IXA → BLR' 'BOM → RPR → VTZ → HYD'
     'BLR → HBX → BOM → AMD → DEL' 'BOM → IDR → DEL → HYD' 'BOM → BLR → HYD'
     'BLR → STV → DEL' 'CCU → IXB → DEL → BLR' 'BOM → JAI → DEL → HYD'
     'BOM → VNS → DEL → HYD' 'BLR → HBX → BOM → NAG → DEL' nan
     'BLR → BOM → IXC → DEL' 'BLR → CCU → BBI → HYD → VGA → DEL'
     'BOM → BBI → HYD']
    ----------------------------------------------------------------
    The unique values in features Dep_Time: 
    ['22:20' '05:50' '09:25' '18:05' '16:50' '09:00' '18:55' '08:00' '08:55'
     '11:25' '09:45' '20:20' '11:40' '21:10' '17:15' '16:40' '08:45' '14:00'
     '20:15' '16:00' '14:10' '22:00' '04:00' '21:25' '21:50' '07:00' '07:05'
     '09:50' '14:35' '10:35' '15:05' '14:15' '06:45' '20:55' '11:10' '05:45'
     '19:00' '23:05' '11:00' '09:35' '21:15' '23:55' '19:45' '08:50' '15:40'
     '06:05' '15:00' '13:55' '05:55' '13:20' '05:05' '06:25' '17:30' '08:20'
     '19:55' '06:30' '14:05' '02:00' '09:40' '08:25' '20:25' '13:15' '02:15'
     '16:55' '20:45' '05:15' '19:50' '20:00' '06:10' '19:30' '04:45' '12:55'
     '18:15' '17:20' '15:25' '23:00' '12:00' '14:45' '11:50' '11:30' '14:40'
     '19:10' '06:00' '23:30' '07:35' '13:05' '12:30' '15:10' '12:50' '18:25'
     '16:30' '00:40' '06:50' '13:00' '19:15' '01:30' '17:00' '10:00' '19:35'
     '15:30' '12:10' '16:10' '20:35' '22:25' '21:05' '05:35' '05:10' '06:40'
     '15:15' '00:30' '08:30' '07:10' '05:30' '14:25' '05:25' '10:20' '17:45'
     '13:10' '22:10' '04:55' '17:50' '21:20' '06:20' '15:55' '20:30' '17:25'
     '09:30' '07:30' '02:35' '10:55' '17:10' '09:10' '18:45' '15:20' '22:50'
     '14:55' '14:20' '13:25' '22:15' '11:05' '16:15' '20:10' '06:55' '19:05'
     '07:55' '07:45' '10:10' '08:15' '11:35' '21:00' '17:55' '16:45' '18:20'
     '03:50' '08:35' '19:20' '20:05' '17:40' '04:40' '17:35' '09:55' '05:00'
     '18:00' '02:55' '20:40' '22:55' '22:40' '21:30' '08:10' '17:05' '07:25'
     '15:45' '09:15' '15:50' '11:45' '22:05' '18:35' '00:25' '19:40' '20:50'
     '22:45' '10:30' '23:25' '11:55' '10:45' '11:15' '12:20' '14:30' '07:15'
     '01:35' '18:40' '09:20' '21:55' '13:50' '01:40' '00:20' '04:15' '13:45'
     '18:30' '06:15' '02:05' '12:15' '13:30' '06:35' '10:05' '08:40' '03:05'
     '21:35' '16:35' '02:30' '16:25' '05:40' '15:35' '13:40' '07:20' '04:50'
     '12:45' '10:25' '12:05' '11:20' '21:40' '03:00']
    ----------------------------------------------------------------
    The unique values in features Arrival_Time: 
    ['01:10 22 Mar' '13:15' '04:25 10 Jun' ... '06:50 10 Mar' '00:05 19 Mar'
     '21:20 13 Mar']
    ----------------------------------------------------------------
    The unique values in features Duration: 
    ['2h 50m' '7h 25m' '19h' '5h 25m' '4h 45m' '2h 25m' '15h 30m' '21h 5m'
     '25h 30m' '7h 50m' '13h 15m' '2h 35m' '2h 15m' '12h 10m' '26h 35m'
     '4h 30m' '22h 35m' '23h' '20h 35m' '5h 10m' '15h 20m' '2h 55m' '13h 20m'
     '15h 10m' '5h 45m' '5h 55m' '13h 25m' '22h' '5h 30m' '10h 25m' '5h 15m'
     '2h 30m' '6h 15m' '11h 55m' '11h 5m' '8h 30m' '22h 5m' '2h 45m' '12h'
     '16h 5m' '19h 55m' '3h 15m' '25h 20m' '3h' '16h 15m' '15h 5m' '6h 30m'
     '25h 5m' '12h 25m' '27h 20m' '10h 15m' '10h 30m' '1h 30m' '1h 25m'
     '26h 30m' '7h 20m' '13h 30m' '5h' '19h 5m' '14h 50m' '2h 40m' '22h 10m'
     '9h 35m' '10h' '21h 20m' '18h 45m' '12h 20m' '18h' '9h 15m' '17h 30m'
     '16h 35m' '12h 15m' '7h 30m' '24h' '8h 55m' '7h 10m' '14h 30m' '30h 20m'
     '15h' '12h 45m' '10h 10m' '15h 25m' '14h 5m' '20h 15m' '23h 10m'
     '18h 10m' '16h' '2h 20m' '8h' '16h 55m' '3h 10m' '14h' '23h 50m'
     '21h 40m' '21h 15m' '10h 50m' '8h 15m' '8h 35m' '11h 50m' '27h 35m'
     '8h 25m' '20h 55m' '4h 50m' '8h 10m' '24h 25m' '23h 35m' '25h 45m'
     '26h 10m' '28h 50m' '25h 15m' '9h 20m' '9h 10m' '3h 5m' '11h 30m'
     '9h 30m' '17h 35m' '5h 5m' '25h 50m' '20h' '13h' '18h 25m' '24h 10m'
     '4h 55m' '25h 35m' '6h 20m' '18h 40m' '19h 25m' '29h 20m' '9h 5m'
     '10h 45m' '11h 40m' '22h 55m' '37h 25m' '25h 40m' '13h 55m' '8h 40m'
     '23h 30m' '12h 35m' '24h 15m' '1h 20m' '11h' '11h 15m' '14h 35m'
     '12h 55m' '9h' '7h 40m' '11h 45m' '24h 55m' '17h 5m' '29h 55m' '22h 15m'
     '14h 40m' '7h 15m' '20h 10m' '20h 45m' '27h' '24h 30m' '20h 25m' '5h 35m'
     '14h 45m' '5h 40m' '4h 5m' '15h 55m' '7h 45m' '28h 20m' '4h 20m' '3h 40m'
     '8h 50m' '23h 45m' '24h 45m' '21h 35m' '8h 5m' '6h 25m' '15h 50m'
     '26h 25m' '24h 50m' '26h' '23h 5m' '7h 55m' '26h 20m' '23h 15m' '5h 20m'
     '4h' '9h 45m' '8h 20m' '17h 25m' '7h 5m' '34h 5m' '6h 5m' '5h 50m' '7h'
     '4h 25m' '13h 45m' '19h 15m' '22h 30m' '16h 25m' '13h 50m' '27h 5m'
     '28h 10m' '4h 40m' '15h 40m' '4h 35m' '18h 30m' '38h 15m' '6h 35m'
     '12h 30m' '11h 20m' '7h 35m' '29h 35m' '26h 55m' '23h 40m' '12h 50m'
     '9h 50m' '21h 55m' '10h 55m' '21h 10m' '20h 40m' '30h' '13h 10m' '8h 45m'
     '6h 10m' '17h 45m' '21h 45m' '3h 55m' '17h 20m' '30h 30m' '21h 25m'
     '12h 40m' '24h 35m' '19h 10m' '22h 40m' '14h 55m' '21h' '6h 45m'
     '28h 40m' '9h 40m' '16h 40m' '16h 20m' '16h 45m' '1h 15m' '6h 55m'
     '11h 25m' '14h 20m' '12h 5m' '24h 5m' '28h 15m' '17h 50m' '20h 20m'
     '28h 5m' '10h 20m' '14h 15m' '35h 15m' '35h 35m' '26h 40m' '28h'
     '14h 25m' '13h 5m' '37h 20m' '36h 10m' '25h 55m' '35h 5m' '19h 45m'
     '27h 55m' '47h' '10h 35m' '1h 35m' '16h 10m' '38h 20m' '6h' '16h 50m'
     '14h 10m' '23h 20m' '17h 40m' '11h 35m' '18h 20m' '6h 40m' '30h 55m'
     '24h 40m' '29h 50m' '28h 25m' '17h 15m' '22h 45m' '25h 25m' '21h 50m'
     '33h 15m' '30h 15m' '3h 35m' '27h 40m' '30h 25m' '18h 50m' '27h 45m'
     '15h 15m' '10h 40m' '26h 15m' '36h 25m' '26h 50m' '15h 45m' '19h 40m'
     '22h 25m' '19h 35m' '25h' '26h 45m' '38h' '4h 15m' '25h 10m' '18h 15m'
     '6h 50m' '23h 55m' '17h 55m' '23h 25m' '17h 10m' '24h 20m' '28h 30m'
     '27h 10m' '19h 20m' '15h 35m' '9h 25m' '21h 30m' '34h 25m' '18h 35m'
     '29h 40m' '26h 5m' '29h 5m' '27h 25m' '16h 30m' '11h 10m' '28h 55m'
     '29h 10m' '34h' '30h 40m' '30h 45m' '32h 55m' '10h 5m' '35h 20m' '32h 5m'
     '31h 40m' '19h 50m' '33h 45m' '30h 10m' '13h 40m' '19h 30m' '31h 30m'
     '34h 30m' '27h 50m' '38h 35m' '42h 5m' '4h 10m' '39h 5m' '3h 50m' '5m'
     '32h 30m' '31h 55m' '33h 20m' '27h 30m' '18h 55m' '9h 55m' '41h 20m'
     '20h 5m' '31h 50m' '42h 45m' '3h 25m' '37h 10m' '29h 30m' '32h 20m'
     '20h 50m' '40h 20m' '13h 35m' '47h 40m']
    ----------------------------------------------------------------
    The unique values in features Total_Stops: 
    ['non-stop' '2 stops' '1 stop' '3 stops' nan '4 stops']
    ----------------------------------------------------------------
    The unique values in features Additional_Info: 
    ['Null ' 'Null' 'In-flight meal not included'
     'No check-in baggage included' '1 Short layover' '1 Long layover'
     'Change airports' 'Business class' 'Red-eye flight' '2 Long layover']
    ----------------------------------------------------------------
    The unique values in features Price: 
    [ 3897  7662 13882 ...  9790 12352 12648]
    ----------------------------------------------------------------
    


```python
for i in df.columns:
    print(f'The value counts in features {i}: ',df[i].value_counts(),sep = '\n')
    print('----------------------------------------------------------------')
```

    The value counts in features Airline: 
    Jet Airways                          3849
    IndiGo                               2053
    Air India                            1752
    Multiple carriers                    1196
    SpiceJet                              818
    Vistara                               479
    Air Asia                              319
    GoAir                                 194
    Multiple carriers Premium economy      13
    Jet Airways Business                    6
    Vistara Premium economy                 3
    Trujet                                  1
    Name: Airline, dtype: int64
    ----------------------------------------------------------------
    The value counts in features Date_of_Journey: 
    18/05/2019    504
    6/06/2019     503
    21/05/2019    497
    9/06/2019     495
    12/06/2019    493
    9/05/2019     484
    21/03/2019    423
    15/05/2019    405
    27/05/2019    382
    27/06/2019    355
    24/06/2019    351
    1/06/2019     342
    3/06/2019     333
    15/06/2019    328
    24/03/2019    323
    6/03/2019     308
    27/03/2019    299
    24/05/2019    286
    6/05/2019     282
    1/05/2019     277
    12/05/2019    259
    1/04/2019     257
    3/03/2019     218
    9/03/2019     200
    15/03/2019    162
    18/03/2019    156
    01/03/2019    152
    12/03/2019    142
    9/04/2019     125
    3/04/2019     110
    21/06/2019    109
    18/06/2019    105
    09/03/2019    102
    6/04/2019     100
    03/03/2019     97
    06/03/2019     95
    27/04/2019     94
    24/04/2019     92
    3/05/2019      90
    15/04/2019     89
    21/04/2019     82
    18/04/2019     67
    12/04/2019     63
    1/03/2019      47
    Name: Date_of_Journey, dtype: int64
    ----------------------------------------------------------------
    The value counts in features Source: 
    Delhi       4537
    Kolkata     2871
    Banglore    2197
    Mumbai       697
    Chennai      381
    Name: Source, dtype: int64
    ----------------------------------------------------------------
    The value counts in features Destination: 
    Cochin       4537
    Banglore     2871
    Delhi        1265
    New Delhi     932
    Hyderabad     697
    Kolkata       381
    Name: Destination, dtype: int64
    ----------------------------------------------------------------
    The value counts in features Route: 
    DEL → BOM → COK          2376
    BLR → DEL                1552
    CCU → BOM → BLR           979
    CCU → BLR                 724
    BOM → HYD                 621
                             ... 
    CCU → VTZ → BLR             1
    CCU → IXZ → MAA → BLR       1
    BOM → COK → MAA → HYD       1
    BOM → CCU → HYD             1
    BOM → BBI → HYD             1
    Name: Route, Length: 128, dtype: int64
    ----------------------------------------------------------------
    The value counts in features Dep_Time: 
    18:55    233
    17:00    227
    07:05    205
    10:00    203
    07:10    202
            ... 
    16:25      1
    01:35      1
    21:35      1
    04:15      1
    03:00      1
    Name: Dep_Time, Length: 222, dtype: int64
    ----------------------------------------------------------------
    The value counts in features Arrival_Time: 
    19:00           423
    21:00           360
    19:15           333
    16:10           154
    12:35           122
                   ... 
    00:25 02 Jun      1
    08:55 13 Mar      1
    11:05 19 May      1
    12:30 22 May      1
    21:20 13 Mar      1
    Name: Arrival_Time, Length: 1343, dtype: int64
    ----------------------------------------------------------------
    The value counts in features Duration: 
    2h 50m     550
    1h 30m     386
    2h 45m     337
    2h 55m     337
    2h 35m     329
              ... 
    31h 30m      1
    30h 25m      1
    42h 5m       1
    4h 10m       1
    47h 40m      1
    Name: Duration, Length: 368, dtype: int64
    ----------------------------------------------------------------
    The value counts in features Total_Stops: 
    1 stop      5625
    non-stop    3491
    2 stops     1520
    3 stops       45
    4 stops        1
    Name: Total_Stops, dtype: int64
    ----------------------------------------------------------------
    The value counts in features Additional_Info: 
    Null                            8347
    In-flight meal not included     1982
    No check-in baggage included     320
    1 Long layover                    19
    Change airports                    7
    Business class                     4
    Null                               1
    1 Short layover                    1
    Red-eye flight                     1
    2 Long layover                     1
    Name: Additional_Info, dtype: int64
    ----------------------------------------------------------------
    The value counts in features Price: 
    10262    258
    10844    212
    7229     162
    4804     160
    4823     131
            ... 
    14153      1
    8488       1
    7826       1
    6315       1
    12648      1
    Name: Price, Length: 1870, dtype: int64
    ----------------------------------------------------------------
    


```python
factor = df['Additional_Info'].isnull().sum()/len(df['Additional_Info'])
```


```python
factor
```




    0.0




```python
factor = len(df[(df['Additional_Info'] == 'Null ')|(df['Additional_Info'] == 'Null')])/len(df['Additional_Info'])
percentage = factor*100
percentage
```




    78.14284377047646



drop Additional_Info columns in preprocessing!


```python
df[(df['Additional_Info'] == 'Null ')|(df['Additional_Info'] == 'Null')]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Airline</th>
      <th>Date_of_Journey</th>
      <th>Source</th>
      <th>Destination</th>
      <th>Route</th>
      <th>Dep_Time</th>
      <th>Arrival_Time</th>
      <th>Duration</th>
      <th>Total_Stops</th>
      <th>Additional_Info</th>
      <th>Price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>IndiGo</td>
      <td>24/03/2019</td>
      <td>Banglore</td>
      <td>New Delhi</td>
      <td>BLR → DEL</td>
      <td>22:20</td>
      <td>01:10 22 Mar</td>
      <td>2h 50m</td>
      <td>non-stop</td>
      <td>Null</td>
      <td>3897</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Air India</td>
      <td>1/05/2019</td>
      <td>Kolkata</td>
      <td>Banglore</td>
      <td>CCU → IXR → BBI → BLR</td>
      <td>05:50</td>
      <td>13:15</td>
      <td>7h 25m</td>
      <td>2 stops</td>
      <td>Null</td>
      <td>7662</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Jet Airways</td>
      <td>9/06/2019</td>
      <td>Delhi</td>
      <td>Cochin</td>
      <td>DEL → LKO → BOM → COK</td>
      <td>09:25</td>
      <td>04:25 10 Jun</td>
      <td>19h</td>
      <td>2 stops</td>
      <td>Null</td>
      <td>13882</td>
    </tr>
    <tr>
      <th>3</th>
      <td>IndiGo</td>
      <td>12/05/2019</td>
      <td>Kolkata</td>
      <td>Banglore</td>
      <td>CCU → NAG → BLR</td>
      <td>18:05</td>
      <td>23:30</td>
      <td>5h 25m</td>
      <td>1 stop</td>
      <td>Null</td>
      <td>6218</td>
    </tr>
    <tr>
      <th>4</th>
      <td>IndiGo</td>
      <td>01/03/2019</td>
      <td>Banglore</td>
      <td>New Delhi</td>
      <td>BLR → NAG → DEL</td>
      <td>16:50</td>
      <td>21:35</td>
      <td>4h 45m</td>
      <td>1 stop</td>
      <td>Null</td>
      <td>13302</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>10678</th>
      <td>Air Asia</td>
      <td>9/04/2019</td>
      <td>Kolkata</td>
      <td>Banglore</td>
      <td>CCU → BLR</td>
      <td>19:55</td>
      <td>22:25</td>
      <td>2h 30m</td>
      <td>non-stop</td>
      <td>Null</td>
      <td>4107</td>
    </tr>
    <tr>
      <th>10679</th>
      <td>Air India</td>
      <td>27/04/2019</td>
      <td>Kolkata</td>
      <td>Banglore</td>
      <td>CCU → BLR</td>
      <td>20:45</td>
      <td>23:20</td>
      <td>2h 35m</td>
      <td>non-stop</td>
      <td>Null</td>
      <td>4145</td>
    </tr>
    <tr>
      <th>10680</th>
      <td>Jet Airways</td>
      <td>27/04/2019</td>
      <td>Banglore</td>
      <td>Delhi</td>
      <td>BLR → DEL</td>
      <td>08:20</td>
      <td>11:20</td>
      <td>3h</td>
      <td>non-stop</td>
      <td>Null</td>
      <td>7229</td>
    </tr>
    <tr>
      <th>10681</th>
      <td>Vistara</td>
      <td>01/03/2019</td>
      <td>Banglore</td>
      <td>New Delhi</td>
      <td>BLR → DEL</td>
      <td>11:30</td>
      <td>14:10</td>
      <td>2h 40m</td>
      <td>non-stop</td>
      <td>Null</td>
      <td>12648</td>
    </tr>
    <tr>
      <th>10682</th>
      <td>Air India</td>
      <td>9/05/2019</td>
      <td>Delhi</td>
      <td>Cochin</td>
      <td>DEL → GOI → BOM → COK</td>
      <td>10:55</td>
      <td>19:15</td>
      <td>8h 20m</td>
      <td>2 stops</td>
      <td>Null</td>
      <td>11753</td>
    </tr>
  </tbody>
</table>
<p>8348 rows × 11 columns</p>
</div>




```python
df.duplicated().sum()
```




    220



## Feature Engineering and Preprocessing


```python
def preprocess(data):
    '''Function preprocesses the data and make it model ready. Simply push dataframe in the function.
    !!! Use only after treating null values or when null values are less enough to drop. It returns two dataframes,
    one for eda and one for model.'''

    data.dropna(inplace = True)

    df.drop_duplicates(inplace = True)

    data['Date_of_Journey'] = pd.to_datetime(data['Date_of_Journey'])
    data['day']=pd.DatetimeIndex(data['Date_of_Journey']).day
    data['month']=pd.DatetimeIndex(data['Date_of_Journey']).month
    data['year']=pd.DatetimeIndex(data['Date_of_Journey']).year
    data['weekday'] = pd.DatetimeIndex(data['Date_of_Journey']).weekday

    data['Total_Stops'] = data['Total_Stops'].str.replace('non-stop','0')
    data['Total_Stops'] = data['Total_Stops'].str.replace('stops','')
    data['Total_Stops'] = data['Total_Stops'].str.replace('stop','')
    data['Total_Stops'] = data['Total_Stops'].str.replace(' ','')
    data['Total_Stops'] = data['Total_Stops'].astype(int)

    data['Destination'] = np.where(data['Destination']=='New Delhi',"Delhi",data['Destination'])
    data['Airline'] = np.where(data['Airline']=='Jet Airways Business',"Jet Airways",data['Airline'])

    Arrival_Time = []
    for i in data['Arrival_Time']:
        Arrival_Time.append(i[:5])
    data['Arrival_Time'] = Arrival_Time
    data['Arrival_Time_Hour'] = pd.DatetimeIndex(data['Arrival_Time']).hour
    data['Arrival_Time_Minutes'] = pd.DatetimeIndex(data['Arrival_Time']).minute

    data['Dep_Time_Hour'] = pd.DatetimeIndex(data['Dep_Time']).hour
    data['Dep_Time_Minute'] = pd.DatetimeIndex(data['Dep_Time']).minute

    data["Duration_Total_Hour"] = data["Duration"].str.replace("h", '*1').str.replace(' ', '+').str.replace('m', '/60').apply(eval)

    data1 = pd.get_dummies(data, prefix=['Airline', 'Source', 'Destination'], columns=['Airline', 'Source','Destination'],drop_first = False)

    data1.drop(['Date_of_Journey','Dep_Time','Arrival_Time','Duration','Additional_Info','year'],axis = 1,inplace = True)
    return data,data1
```


```python
data_eda, data_model = preprocess(df)
```


```python
data_eda
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Airline</th>
      <th>Date_of_Journey</th>
      <th>Source</th>
      <th>Destination</th>
      <th>Route</th>
      <th>Dep_Time</th>
      <th>Arrival_Time</th>
      <th>Duration</th>
      <th>Total_Stops</th>
      <th>Additional_Info</th>
      <th>Price</th>
      <th>day</th>
      <th>month</th>
      <th>year</th>
      <th>weekday</th>
      <th>Arrival_Time_Hour</th>
      <th>Arrival_Time_Minutes</th>
      <th>Dep_Time_Hour</th>
      <th>Dep_Time_Minute</th>
      <th>Duration_Total_Hour</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>IndiGo</td>
      <td>2019-03-24</td>
      <td>Banglore</td>
      <td>Delhi</td>
      <td>BLR → DEL</td>
      <td>22:20</td>
      <td>01:10</td>
      <td>2h 50m</td>
      <td>0</td>
      <td>Null</td>
      <td>3897</td>
      <td>24</td>
      <td>3</td>
      <td>2019</td>
      <td>6</td>
      <td>1</td>
      <td>10</td>
      <td>22</td>
      <td>20</td>
      <td>2.833333</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Air India</td>
      <td>2019-01-05</td>
      <td>Kolkata</td>
      <td>Banglore</td>
      <td>CCU → IXR → BBI → BLR</td>
      <td>05:50</td>
      <td>13:15</td>
      <td>7h 25m</td>
      <td>2</td>
      <td>Null</td>
      <td>7662</td>
      <td>5</td>
      <td>1</td>
      <td>2019</td>
      <td>5</td>
      <td>13</td>
      <td>15</td>
      <td>5</td>
      <td>50</td>
      <td>7.416667</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Jet Airways</td>
      <td>2019-09-06</td>
      <td>Delhi</td>
      <td>Cochin</td>
      <td>DEL → LKO → BOM → COK</td>
      <td>09:25</td>
      <td>04:25</td>
      <td>19h</td>
      <td>2</td>
      <td>Null</td>
      <td>13882</td>
      <td>6</td>
      <td>9</td>
      <td>2019</td>
      <td>4</td>
      <td>4</td>
      <td>25</td>
      <td>9</td>
      <td>25</td>
      <td>19.000000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>IndiGo</td>
      <td>2019-12-05</td>
      <td>Kolkata</td>
      <td>Banglore</td>
      <td>CCU → NAG → BLR</td>
      <td>18:05</td>
      <td>23:30</td>
      <td>5h 25m</td>
      <td>1</td>
      <td>Null</td>
      <td>6218</td>
      <td>5</td>
      <td>12</td>
      <td>2019</td>
      <td>3</td>
      <td>23</td>
      <td>30</td>
      <td>18</td>
      <td>5</td>
      <td>5.416667</td>
    </tr>
    <tr>
      <th>4</th>
      <td>IndiGo</td>
      <td>2019-01-03</td>
      <td>Banglore</td>
      <td>Delhi</td>
      <td>BLR → NAG → DEL</td>
      <td>16:50</td>
      <td>21:35</td>
      <td>4h 45m</td>
      <td>1</td>
      <td>Null</td>
      <td>13302</td>
      <td>3</td>
      <td>1</td>
      <td>2019</td>
      <td>3</td>
      <td>21</td>
      <td>35</td>
      <td>16</td>
      <td>50</td>
      <td>4.750000</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>10678</th>
      <td>Air Asia</td>
      <td>2019-09-04</td>
      <td>Kolkata</td>
      <td>Banglore</td>
      <td>CCU → BLR</td>
      <td>19:55</td>
      <td>22:25</td>
      <td>2h 30m</td>
      <td>0</td>
      <td>Null</td>
      <td>4107</td>
      <td>4</td>
      <td>9</td>
      <td>2019</td>
      <td>2</td>
      <td>22</td>
      <td>25</td>
      <td>19</td>
      <td>55</td>
      <td>2.500000</td>
    </tr>
    <tr>
      <th>10679</th>
      <td>Air India</td>
      <td>2019-04-27</td>
      <td>Kolkata</td>
      <td>Banglore</td>
      <td>CCU → BLR</td>
      <td>20:45</td>
      <td>23:20</td>
      <td>2h 35m</td>
      <td>0</td>
      <td>Null</td>
      <td>4145</td>
      <td>27</td>
      <td>4</td>
      <td>2019</td>
      <td>5</td>
      <td>23</td>
      <td>20</td>
      <td>20</td>
      <td>45</td>
      <td>2.583333</td>
    </tr>
    <tr>
      <th>10680</th>
      <td>Jet Airways</td>
      <td>2019-04-27</td>
      <td>Banglore</td>
      <td>Delhi</td>
      <td>BLR → DEL</td>
      <td>08:20</td>
      <td>11:20</td>
      <td>3h</td>
      <td>0</td>
      <td>Null</td>
      <td>7229</td>
      <td>27</td>
      <td>4</td>
      <td>2019</td>
      <td>5</td>
      <td>11</td>
      <td>20</td>
      <td>8</td>
      <td>20</td>
      <td>3.000000</td>
    </tr>
    <tr>
      <th>10681</th>
      <td>Vistara</td>
      <td>2019-01-03</td>
      <td>Banglore</td>
      <td>Delhi</td>
      <td>BLR → DEL</td>
      <td>11:30</td>
      <td>14:10</td>
      <td>2h 40m</td>
      <td>0</td>
      <td>Null</td>
      <td>12648</td>
      <td>3</td>
      <td>1</td>
      <td>2019</td>
      <td>3</td>
      <td>14</td>
      <td>10</td>
      <td>11</td>
      <td>30</td>
      <td>2.666667</td>
    </tr>
    <tr>
      <th>10682</th>
      <td>Air India</td>
      <td>2019-09-05</td>
      <td>Delhi</td>
      <td>Cochin</td>
      <td>DEL → GOI → BOM → COK</td>
      <td>10:55</td>
      <td>19:15</td>
      <td>8h 20m</td>
      <td>2</td>
      <td>Null</td>
      <td>11753</td>
      <td>5</td>
      <td>9</td>
      <td>2019</td>
      <td>3</td>
      <td>19</td>
      <td>15</td>
      <td>10</td>
      <td>55</td>
      <td>8.333333</td>
    </tr>
  </tbody>
</table>
<p>10462 rows × 20 columns</p>
</div>




```python
data_model
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Route</th>
      <th>Total_Stops</th>
      <th>Price</th>
      <th>day</th>
      <th>month</th>
      <th>weekday</th>
      <th>Arrival_Time_Hour</th>
      <th>Arrival_Time_Minutes</th>
      <th>Dep_Time_Hour</th>
      <th>Dep_Time_Minute</th>
      <th>...</th>
      <th>Source_Banglore</th>
      <th>Source_Chennai</th>
      <th>Source_Delhi</th>
      <th>Source_Kolkata</th>
      <th>Source_Mumbai</th>
      <th>Destination_Banglore</th>
      <th>Destination_Cochin</th>
      <th>Destination_Delhi</th>
      <th>Destination_Hyderabad</th>
      <th>Destination_Kolkata</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>BLR → DEL</td>
      <td>0</td>
      <td>3897</td>
      <td>24</td>
      <td>3</td>
      <td>6</td>
      <td>1</td>
      <td>10</td>
      <td>22</td>
      <td>20</td>
      <td>...</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>CCU → IXR → BBI → BLR</td>
      <td>2</td>
      <td>7662</td>
      <td>5</td>
      <td>1</td>
      <td>5</td>
      <td>13</td>
      <td>15</td>
      <td>5</td>
      <td>50</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>DEL → LKO → BOM → COK</td>
      <td>2</td>
      <td>13882</td>
      <td>6</td>
      <td>9</td>
      <td>4</td>
      <td>4</td>
      <td>25</td>
      <td>9</td>
      <td>25</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>CCU → NAG → BLR</td>
      <td>1</td>
      <td>6218</td>
      <td>5</td>
      <td>12</td>
      <td>3</td>
      <td>23</td>
      <td>30</td>
      <td>18</td>
      <td>5</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>BLR → NAG → DEL</td>
      <td>1</td>
      <td>13302</td>
      <td>3</td>
      <td>1</td>
      <td>3</td>
      <td>21</td>
      <td>35</td>
      <td>16</td>
      <td>50</td>
      <td>...</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>10678</th>
      <td>CCU → BLR</td>
      <td>0</td>
      <td>4107</td>
      <td>4</td>
      <td>9</td>
      <td>2</td>
      <td>22</td>
      <td>25</td>
      <td>19</td>
      <td>55</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>10679</th>
      <td>CCU → BLR</td>
      <td>0</td>
      <td>4145</td>
      <td>27</td>
      <td>4</td>
      <td>5</td>
      <td>23</td>
      <td>20</td>
      <td>20</td>
      <td>45</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>10680</th>
      <td>BLR → DEL</td>
      <td>0</td>
      <td>7229</td>
      <td>27</td>
      <td>4</td>
      <td>5</td>
      <td>11</td>
      <td>20</td>
      <td>8</td>
      <td>20</td>
      <td>...</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>10681</th>
      <td>BLR → DEL</td>
      <td>0</td>
      <td>12648</td>
      <td>3</td>
      <td>1</td>
      <td>3</td>
      <td>14</td>
      <td>10</td>
      <td>11</td>
      <td>30</td>
      <td>...</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>10682</th>
      <td>DEL → GOI → BOM → COK</td>
      <td>2</td>
      <td>11753</td>
      <td>5</td>
      <td>9</td>
      <td>3</td>
      <td>19</td>
      <td>15</td>
      <td>10</td>
      <td>55</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>10462 rows × 32 columns</p>
</div>




```python
data_model.drop('Route',inplace = True,axis=1)
```


```python
X = data_model.drop('Price', axis = 1)
y = data_model['Price']
```


```python
from sklearn.model_selection import train_test_split
```


```python
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.2,random_state = 42)
```


```python
from sklearn.ensemble import ExtraTreesRegressor
```


```python
extractor = ExtraTreesRegressor(random_state = 42)
```


```python
extractor.fit(X_train,y_train)
```




<style>#sk-container-id-1 {color: black;background-color: white;}#sk-container-id-1 pre{padding: 0;}#sk-container-id-1 div.sk-toggleable {background-color: white;}#sk-container-id-1 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-1 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-1 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-1 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-1 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-1 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-1 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-1 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-1 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-1 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-1 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-1 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-1 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-1 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-1 div.sk-item {position: relative;z-index: 1;}#sk-container-id-1 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-1 div.sk-item::before, #sk-container-id-1 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-1 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-1 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-1 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-1 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-1 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-1 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-1 div.sk-label-container {text-align: center;}#sk-container-id-1 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-1 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-1" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>ExtraTreesRegressor(random_state=42)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-1" type="checkbox" checked><label for="sk-estimator-id-1" class="sk-toggleable__label sk-toggleable__label-arrow">ExtraTreesRegressor</label><div class="sk-toggleable__content"><pre>ExtraTreesRegressor(random_state=42)</pre></div></div></div></div></div>




```python
x_columns = X_train.columns
feature_rank = pd.DataFrame({'feature':x_columns,'importances':extractor.feature_importances_})
```


```python
feature_rank = feature_rank.sort_values('importances',ascending = False)
```


```python
sns.barplot(y='feature',x='importances',data=feature_rank)
```




    <AxesSubplot:xlabel='importances', ylabel='feature'>




    
![png](output_28_1.png)
    



```python

```
